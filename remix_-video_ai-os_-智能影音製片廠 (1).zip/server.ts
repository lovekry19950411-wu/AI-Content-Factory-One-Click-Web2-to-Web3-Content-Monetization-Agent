import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import mongoose from "mongoose";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// MongoDB Schema
const scriptSchema = new mongoose.Schema({
  id: String,
  userAddress: String,
  type: String,
  platform: String,
  topic: String,
  content: String,
  timestamp: Number,
  wordCount: Number
});

const userSchema = new mongoose.Schema({
  address: { type: String, unique: true },
  credits: { type: Number, default: 0 },
  referralCode: { type: String, unique: true },
  invitedBy: String,
  invitesCount: { type: Number, default: 0 },
  createdAt: { type: Number, default: Date.now }
});

const Script = mongoose.model("Script", scriptSchema);
const User = mongoose.model("User", userSchema);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Connect to MongoDB if URI is provided
  const mongodbUri = process.env.MONGODB_URI;
  if (mongodbUri) {
    mongoose.connect(mongodbUri, {
      serverSelectionTimeoutMS: 5000,
    }).then(() => {
      console.log("Connected to MongoDB Atlas");
    }).catch((err: any) => {
      console.error("CRITICAL: MongoDB connection error!");
      console.error("Reason:", err.message);
    });
  } else {
    console.warn("MONGODB_URI not provided. Skipping database connection.");
  }

  // User Routes
  const fallbackUsers: Record<string, any> = {};

  app.get("/api/user/:address", async (req, res) => {
    const { address } = req.params;
    try {
      if (mongoose.connection.readyState !== 1) {
        if (!fallbackUsers[address]) {
          const referralCode = Math.random().toString(36).substring(2, 8).toUpperCase();
          fallbackUsers[address] = { address, referralCode, credits: 5, invitesCount: 0 }; 
        }
        return res.json(fallbackUsers[address]);
      }
      let user = await User.findOne({ address });
      if (!user) {
        const referralCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        user = new User({ address, referralCode, credits: 0 });
        await user.save();
      }
      res.json(user);
    } catch (err) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.post("/api/user/:address/refer", async (req, res) => {
    const { address } = req.params;
    const { code } = req.body;
    try {
      if (mongoose.connection.readyState !== 1) {
        const user = fallbackUsers[address];
        if (user && !user.invitedBy && code) {
          const inviter = Object.values(fallbackUsers).find((u: any) => u.referralCode === code);
          if (inviter && inviter.address !== address) {
            user.invitedBy = inviter.address;
            user.credits += 1;
            inviter.invitesCount += 1;
            inviter.credits += 2;
            return res.json({ success: true, message: "Referral applied! Bonus credits added." });
          }
        }
        return res.json({ success: false, message: "Invalid or already applied" });
      }
      const user = await User.findOne({ address });
      if (user && !user.invitedBy && code) {
        const inviter = await User.findOne({ referralCode: code });
        if (inviter && inviter.address !== address) {
          user.invitedBy = inviter.address;
          user.credits += 1; // Bonus for invited user
          await user.save();

          inviter.invitesCount += 1;
          inviter.credits += 2; // Viral Bonus for inviter
          await inviter.save();
          return res.json({ success: true, message: "Referral applied! Bonus credits added." });
        }
      }
      res.json({ success: false, message: "Invalid or already applied" });
    } catch (err) {
      res.status(500).json({ error: "Referral failed" });
    }
  });

  app.post("/api/user/:address/topup", async (req, res) => {
    const { address } = req.params;
    const { amount } = req.body; // number of credits
    try {
      if (mongoose.connection.readyState !== 1) {
        if (fallbackUsers[address]) {
          fallbackUsers[address].credits += amount;
          return res.json(fallbackUsers[address]);
        }
        return res.status(404).json({ error: "User not found" });
      }
      const user = await User.findOne({ address });
      if (user) {
        user.credits += amount;
        await user.save();
        res.json(user);
      } else {
        res.status(404).json({ error: "User not found" });
      }
    } catch (err) {
      res.status(500).json({ error: "Topup failed" });
    }
  });

  app.post("/api/user/:address/spend", async (req, res) => {
    const { address } = req.params;
    try {
      if (mongoose.connection.readyState !== 1) {
        if (fallbackUsers[address] && fallbackUsers[address].credits > 0) {
          fallbackUsers[address].credits -= 1;
          return res.json({ success: true, credits: fallbackUsers[address].credits });
        }
        return res.status(400).json({ error: "Insufficient credits" });
      }
      const user = await User.findOne({ address });
      if (user && user.credits > 0) {
        user.credits -= 1;
        await user.save();
        res.json({ success: true, credits: user.credits });
      } else {
        res.status(400).json({ error: "Insufficient credits" });
      }
    } catch (err) {
      res.status(500).json({ error: "Spend failed" });
    }
  });

  // AI Generation Route (The core logic for viral-gen)
  app.post("/api/viral-gen", async (req, res) => {
    try {
      const { type, platform, topic, extraInstructions } = req.body;

      if (!apiKey || apiKey.length < 5) {
        return res.status(500).json({ error: "伺服器未設置 GEMINI_API_KEY。請至 Settings > Secrets 設置。" });
      }

      const prompts: Record<string, string> = {
        video_script: `為 ${platform} 策劃一個專業細緻的影音腳本。話題：${topic}。要求：包含詳細分鏡、對話文稿、背景音樂建議。`,
        visual_prompt: `為 Luma/Runway 生成高品質視覺提示詞。話題：${topic}。要求：英文描述，包含專業燈光、攝影機運動、電影級質感。`,
        subtitle_gen: `為 "${topic}" 生成具備行銷張力的社交媒體字幕。`,
        ai_edit_plan: `為 "${topic}" 提供專門的影音剪輯流程指南。`
      };

      const promptText = `${prompts[type] || prompts.video_script} 額外要求：${extraInstructions || "無"}。直接輸出內容。`;
      
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: promptText,
      });
      
      const text = response.text;
      if (!text) throw new Error("AI 返回空內容");
      res.send(text);
    } catch (err: any) {
      console.error("Gemini Error:", err);
      res.status(500).json({ error: "AI 生成出錯: " + (err.message || "未知錯誤") });
    }
  });

  // API Routes (Moved below AI Gen to avoid confusion)
  const fallbackScripts: any[] = [];

  app.get("/api/scripts", async (req, res) => {
    const address = req.query.address as string;
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json(fallbackScripts.filter(s => !address || s.userAddress === address).sort((a, b) => b.timestamp - a.timestamp));
      }
      const query = address ? { userAddress: address } : {};
      const scripts = await Script.find(query).sort({ timestamp: -1 });
      res.json(scripts);
    } catch (err) {
      console.error("Fetch Scripts Error:", err);
      res.status(500).json({ error: "Failed to fetch scripts" });
    }
  });

  app.post("/api/scripts", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        fallbackScripts.push(req.body);
        return res.status(201).json(req.body);
      }
      const newScript = new Script(req.body);
      await newScript.save();
      res.status(201).json(newScript);
    } catch (err) {
      res.status(500).json({ error: "Failed to save script" });
    }
  });

  app.delete("/api/scripts/:id", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        const index = fallbackScripts.findIndex(s => s.id === req.params.id);
        if (index > -1) fallbackScripts.splice(index, 1);
        return res.status(200).json({ message: "Deleted successfully" });
      }
      await Script.deleteOne({ id: req.params.id });
      res.status(200).json({ message: "Deleted successfully" });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete script" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
